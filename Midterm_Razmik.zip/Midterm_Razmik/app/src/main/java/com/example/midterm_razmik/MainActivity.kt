package com.example.midterm_razmik

import android.icu.number.IntegerWidth
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

abstract class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }

    abstract var A: ArrayList<Integer>
    abstract var B: ArrayList<Integer>
    abstract var C: ArrayList<Integer>


    fun towerSolver(n: Int): ArrayList<Integer>
    {
        val max:Int = n

        while(C.size != max) {
            if(C.isEmpty() || ((A.last() < C.last())) && B.last() > C.last())
            {
                C.add(A.last())
                A.removeLast()
            }
            else if(B.isEmpty() || ((B.last() > C.last()) && A.last() < B.last()))
            {
                B.add(A.last())
                A.removeLast()
            }
            else if(A.isEmpty() || ((A.last() < C.last())))
            {
                A.add(B.last())
                B.removeLast()
            }
            if((C.last() > A.last()) && (B.last() < C.last()))
            {
                C.add(B.last())
                B.removeLast()
            }
        }
        return C
    }
}
